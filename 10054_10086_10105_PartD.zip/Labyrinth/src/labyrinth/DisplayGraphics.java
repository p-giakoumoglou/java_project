package labyrinth;
import javax.swing.*;
import java.awt.*;

public class DisplayGraphics extends JPanel{
    private static final long serialVersionUID = 1L;   // for the serialization of the images
    Board board;
    Player[] players;

    DisplayGraphics(Board board, Player[] players) {  // Constructor
        this.board = board;
        this.players = players;
    }

    public void paint(Graphics g) {

        //initialize size, position and colors

        super.paint(g);
        int startX = 0;
        int startY = 0;
        int size = 600;
        int box = 40;

        Color color = new Color(199,174,165);
        setBackground(color);
        color = new Color(255,255,255);
        g.setColor(color);
        g.fillRect(startX, startY,size, size);
        color = new Color(0, 0, 0);
        g.setColor(color);

        int N = board.getN();  // The dimensions of the Labyrinth

        // The algorithm for drawing the Labyrinth and its walls (x : columns , y : rows) //

        for(int y = 0; y < N; y++) {
            for(int x = 0; x < N; x++) {
                if(board.tiles[y * N + x].getDown()) {      //if there's a wall at the down side of the Tile
                    g.drawLine(startX + x * box, startY + size - y * box, startX + (x + 1) * box, startY + size - y * box);
                }

                if(board.tiles[y * N + x].getLeft()) {      //if there's a wall at the left side of the Tile
                    g.drawLine(startX + x * box, startY + size - y * box , startX + x * box, startY + size - (y + 1) * box);
                }

                if(board.tiles[y * N + x].getUp()) {        //if there's a wall at the upper side of the Tile
                    g.drawLine(startX + x * box, startY + size - (y + 1) * box, startX + (x + 1) * box, startY + size - (y + 1) * box);
                }

                if(board.tiles[y * N + x].getRight()) {     //if there's a wall at the right side of the Tile
                    g.drawLine(startX + (x + 1) * box, startY + size - y * box, startX + (x + 1) * box, startY + size - (y + 1) * box);
                }
            }
        }

        Toolkit t = Toolkit.getDefaultToolkit(); // class for the implementations of a Window
        Image i1 = t.getImage("theseus.png"); // image to symbolize Theseus
        g.drawImage(i1, startX + players[0].getY() * box, startY + size - (players[0].getX() + 1) * box,this); // initialize the position of Theseus' image in rectangle

        Image i2 = t.getImage("minotaur.png"); // image to symbolize Minotaur
        g.drawImage(i2, startX + players[1].getY() * box, startY + size - (players[1].getX() + 1) * box,this); // initialize the position of Minotaur's image in rectangle

        Image i3 = t.getImage("supply.png"); // image to symbolize Supply
        for(int k = 0; k < board.getS(); k++) {  // positioning the images at the Tiles that include a Supply in rectangle
            if(board.supplies[k].getSupplyTileId() == 0) {
                continue;
            }
            g.drawImage(i3, startX + board.supplies[k].getY() * box, startY + (N - 1 - board.supplies[k].getX()) * box, this);
        }
    }
}