// Aris-Eftychios Kyprianidis 10086 6988252395 akyprian@ece.auth.gr
// Christos Kyratsous 10105 6933359945 chrkyrlaz@ece.auth.gr
// Paschalis Giakoumoglou 10054 6988031719 giakoupg@ece.auth.gr

package labyrinth;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


// Class Game 
public class Game{
	int round;
	boolean restart = false;
	int whatPlayer = 0; // theseus, 0 for random, 1 for heuristic, 2 for minmax
	int speed = 50; // the speed of the players moving in the graphics,used on slider

	
// 1st constructor
	public Game() {
		round = 0;
	}
	
// 2nd constructor
	public Game(int round) {
		this.round = round;
	}
	
// getters and setters for class Game
	public int getRound() {
		return round;
	}
	
	public boolean getRestart() {
		return restart;
	}
	
	public void setRestart(boolean restart) {
		this.restart = restart;
	}
	
	public void setRound(int round) {
		this.round = round;
	}
	
	public static void printTable(Board board, int id, int enemyId) {
		for(int i = board.getN() * 2; i > -1; i--) {
			for(int j = 0; j < board.getN(); j++) {
				System.out.print(board.getStringRepresentation(id, enemyId)[i][j]);
			}
			System.out.println("");
		}
	}
	
	public static boolean setTurns() {  // returns random boolean, false for theseus, true for minotaur
		return new Random().nextBoolean();
		//return false;
		//return true;
	}
	
	
	// mains
		//3 for were about 5 minutes , 4 for were about 1.5 hours
			public static void weightFinder() {
				int N = 15; // the dimension of the board
				int totalRounds = 200;
				double max = 0;//initializing the max
				double[] globalWeight = {0,0,0,0,0};
					for(double c = 1; c < 10; c+=0.5) {//for the weight of supply
						System.out.println("c= "+c);
						for(int b = 30; b < 90; b+=2) {//for the weight of dangerous
							//System.out.println("b= "+b);
							for(double d = 10; d < 100; d+=5) {//for the weight explore
								//System.out.println("d= "+d);
								for(double e = 10; e < 100; e+=5) {//for the weight of recently touched
									double[] weight = {10.0, b, c, d, e}; //the set of weights
									double[] globalStats = {0,0,0,0,0,0};
									int games = 0;
									//for each set of weights we run 100 games
									while(games<100) {
										Game game = new Game(); // initializing the game
										Board board = new Board(N, 4, (N * N * 3 + 1) / 2); // initializing the board
										Player[] players = new Player[2]; // creates players
										players[0] = new HeuristicPlayer(board, "Theseus", 0, 0 ,0, N*N/2, weight); // theseus  with a set of weights
										players[1] = new SimplePlayer(board, "Minotaur", 1, board.getN() / 2 ,board.getN() / 2); // minotaur
										board.createBoard(); // creates Board
										
										//rounds, each set has 200 rounds
										while(game.getRound() < totalRounds) {

											int[] array1 = ((HeuristicPlayer)players[0]).getNextMove(players[0].getX() * board.getN() + players[0].getY(),players[1].getX() * board.getN() + players[1].getY());
											if(array1[3] != -1 && board.getSupplies()[array1[3]].getSupplyTileId() != 0) { // if theseus got a supply that isn't at (0,0), move the supply to (0,0) and show it
												players[0].setScore(players[0].getScore() + 1);
												board.getSupplies()[array1[3]].setSupplyTileId(0);
												board.getSupplies()[array1[3]].setX(0);
												board.getSupplies()[array1[3]].setY(0);
											}
											players[0].setX(array1[1]);
											players[0].setY(array1[2]);
											
											int[] array2 = players[1].getNextMove(players[1].getX() * board.getN() + players[1].getY(), players[0].getX() * board.getN() + players[0].getY());
											players[1].setX(array2[1]);
											players[1].setY(array2[2]);
												
								
											// increasing round by 1
											game.setRound(game.getRound() + 1);
											
											boolean check = true; // checks if all the supplies are at the tile 0
											for(int i = 0; i < board.getS(); i++) {
												if(board.getSupplies()[i].getSupplyTileId() != 0) {
													check = false;
													break;
												}
											}
											
											// winning condition for theseus
											if(check) {
												globalStats[0]++;
												globalStats[1]+=game.getRound() + 1;//not used
												break;
											}
											// winning condition for minotaur
											if((players[0].getX() * board.getN() + players[0].getY()) == (players[1].getX() * board.getN() + players[1].getY())) {
												globalStats[2]++;//can be used if we want the minimum loss rate
												globalStats[3]+=game.getRound() + 1;//not used
												globalStats[4]+=players[0].getScore();//not used
												break;
											}
											
										}
										// tie condition if they run out of turns
										if(game.getRound() == totalRounds) { 
											globalStats[5]++;
											//System.out.println("No one won..."); 
										}
										
										games++;
									}
									globalStats[0]/=games;
									if(max < globalStats[0]) {//if the new win rate is better
										max = globalStats[0];//we keep the new win rate
										globalWeight[0] = weight[0];
										globalWeight[1] = weight[1];//not used
										globalWeight[2] = weight[2];//can be used if we want the minimum loss rate
										globalWeight[3] = weight[3];//not used
										globalWeight[4] = weight[4];//not used
									}
									
									for(int i = 0; i < 6; i++) {
										globalStats[i] = 0;
									}
								}
							}
						}
					}
				System.out.println("a= " + globalWeight[0] +" b= " + globalWeight[1] + " c= " + globalWeight[2] + " d= " + globalWeight[3] + " e= " + globalWeight[4]);
				
			}
			
			public static void statisticsProgram() {
				double[] weight = {10.0, 76.0, 2.5, 65.0, 25.0}; 
				double[] globalStats = {0,0,0,0,0,0,0,0};
				int N = 15; // the dimension of the board
				int totalRounds = 1000;//the rounds for each game
				int games = 0;
				
			
				
				//we run 1000 games
				while(games<1000) {
					//System.out.println("Game: " + games);
					Game game = new Game(); // initializing the game
					Board board = new Board(N, 4, (N * N * 3 + 1) / 2); // initializing the board
					Player[] players = new Player[2]; // creates players
					players[0] = new MinMaxPlayer(board, "Theseus", 0, 0 ,0, N*N/2, weight, 6, false, true); // theseus
					players[1] = new SimplePlayer(board, "Minotaur", 1, board.getN() / 2 ,board.getN() / 2); // minotaur
					board.createBoard(); // creates Board
					//rounds
					while(game.getRound() < totalRounds) {
					
						int[] array1 = players[0].getNextMove(players[0].getX() * board.getN() + players[0].getY(),players[1].getX() * board.getN() + players[1].getY());
						if(array1[3] != -1 && board.getSupplies()[array1[3]].getSupplyTileId() != 0) { // if theseus got a supply that isn't at (0,0), move the supply to (0,0) and show it
							//System.out.println("He got S" + (array1[3] + 1) + " supply!");
							players[0].setScore(players[0].getScore() + 1);
							board.getSupplies()[array1[3]].setSupplyTileId(0);
							board.getSupplies()[array1[3]].setX(0);
							board.getSupplies()[array1[3]].setY(0);
						}
						players[0].setX(array1[1]);
						players[0].setY(array1[2]);
						
						// setting the new coordinates of the players
						
						int[] array2 = players[1].getNextMove(players[1].getX() * board.getN() + players[1].getY(), players[0].getX() * board.getN() + players[0].getY());
						players[1].setX(array2[1]);
						players[1].setY(array2[2]);
							
			
						// increasing round by 1
						game.setRound(game.getRound() + 1);
						
						boolean check = true; // checks if all the supplies are at the tile 0
						for(int i = 0; i < board.getS(); i++) {
							if(board.getSupplies()[i].getSupplyTileId() != 0) {
								check = false;
								break;
							}
						}
						
							
						
						// winning condition for theseus
						if(check) {
							globalStats[0]++;//this is for the total winds
							globalStats[1]+=game.getRound() + 1;//this is for the rounds theseus won
							break;
						}
						// winning condition for minotaur
						if((players[0].getX() * board.getN() + players[0].getY()) == (players[1].getX() * board.getN() + players[1].getY())) {
							globalStats[2]++;//this for the total loses
							globalStats[3]+=game.getRound() + 1;//this for the rounds theseus won
							globalStats[4]+=players[0].getScore();//this is for the supplies won before losing
							if( players[0].getCheck() == true ){//Reminder: check shows if theseus saw the minotaur with vision
								globalStats[6]++;//if he did and he lost that means he made a wrong move		
							}
							else globalStats[7]++;//if not the death was an ambush
//							for(int i = board.getN() * 2; i > -1; i--) {
//								for(int j = 0; j < board.getN(); j++) {
//									System.out.print(board.getStringRepresentation(array1[0],array2[0])[i][j]);
//								}
//								System.out.println("");
//							}
							break;
						}
						
					}
					if(game.getRound() == totalRounds) { 
						globalStats[5]++;
					}
					
					games++;
				}
				//Printing the statis
				System.out.println("Winning Rate " + globalStats[0]/(games));
				System.out.println("Average Winning Round " + globalStats[1]/globalStats[0]);
				System.out.println("Losing Rate " + globalStats[2]/(games));
				System.out.println("Average Losing Round: " + globalStats[3]/(globalStats[2]));
				System.out.println("Average Supplies Won before losing: " + globalStats[4]/(globalStats[2]));
				System.out.println("Draws Rate: " + globalStats[5]/(games));
				System.out.println("Suicides: " + globalStats[6]);
				System.out.println("Ambushes: " + globalStats[7]);
				
				
			}
			
			public static void mainProgram() {
		        
				Game game = new Game(); // initializing the game
				int N = 15; // the dimension of the board
				int totalRounds = 200;
				Board board = new Board(N, 4, (N * N * 3 + 1) / 2); // initializing the board
				Player[] players = new Player[2]; // creates players
				double[] weight = {10.0, 40.0, 2.5, 20.0, 20.0};
				players[0] = new Player(board, "Theseus", 0, 0 ,0); // theseus
				players[1] = new SimplePlayer(board, "Minotaur", 1, board.getN() / 2 ,board.getN() / 2); // minotaur
				
				JFrame f = new JFrame("Labyrinth"); // adds frame 
				f.setLayout(null); // we dont use a layout, we put them directly on the frame on specific points
				Color color = new Color(199,174,165); // color for background
				f.getContentPane().setBackground( color ); 
				
				//Labels
				JLabel l1,l2,l3,l4,l5,l6,l7;  
				l1=new JLabel("Theseus");
				l1.setBounds(10, 550, 80, 40); // setBounds put component in the specific location
				l1.setFont(new Font("Times New Roman", Font.BOLD, 20)); // style of characters
				f.add(l1);
				
				l2=new JLabel("Move Score: ");
				l2.setBounds(10,600,150,40);
				l2.setFont(new Font("Times New Roman", Font.BOLD, 20));
				f.add(l2);
	
				l3=new JLabel("Total Score: ");  
				l3.setBounds(10,650, 150,40);
				l3.setFont(new Font("Times New Roman", Font.BOLD, 20));
				f.add(l3);
				
				l4=new JLabel("Minotaur");  
				l4.setBounds(800,550, 100,40);
				l4.setFont(new Font("Times New Roman", Font.BOLD, 20));
				f.add(l4);
				
				l5=new JLabel("Move Score: ");  
				l5.setBounds(800,600, 150,40);
				l5.setFont(new Font("Times New Roman", Font.BOLD, 20));
				f.add(l5);
				
				l6=new JLabel("Round: ");  
				l6.setBounds(10,50, 100,40);
				l6.setFont(new Font("Times New Roman", Font.BOLD, 20));
				f.add(l6);
				
				l7=new JLabel("Speed ");  
				l7.setBounds(10,100, 100,40);
				l7.setFont(new Font("Times New Roman", Font.BOLD, 20));
				f.add(l7);
				
				//ComboBox for Theseus
		        String playerTheseus[]={"Random","Heuristic","MinMax"};
				JComboBox<String> cbTheseus = new JComboBox<>(playerTheseus);
				cbTheseus.setBounds(10, 700, 150, 40);
				f.add(cbTheseus);
				cbTheseus.addActionListener(new ActionListener() {  //whenever we choose an option on the combobox 
					public void actionPerformed(ActionEvent e) {       
						if("Random" == cbTheseus.getItemAt(cbTheseus.getSelectedIndex())) {
							players[0] = new Player(board, "Theseus", 0, 0 ,0); // theseus
							game.whatPlayer = 0;
						}
						else if("Heuristic" == cbTheseus.getItemAt(cbTheseus.getSelectedIndex())) {
							players[0] = new HeuristicPlayer(board, "Theseus", 0, 0 ,0,N*N/2, weight); // theseus
							game.whatPlayer = 1;
						}
						else if("MinMax" == cbTheseus.getItemAt(cbTheseus.getSelectedIndex())) {
							players[0] = new MinMaxPlayer(board, "Theseus", 0, 0 ,0,N*N/2, weight, 6, false, true); // theseus
							game.whatPlayer = 2;
						}
					}  
				}); 

				//ComboBox for Minotaur
				String playerMinotaur[]={"Random","Simple"};
				JComboBox<String> cbMin = new JComboBox<>(playerMinotaur);
				cbMin.setBounds(800, 700, 150, 40);
				f.add(cbMin);
				cbMin.addActionListener(new ActionListener() {  
					public void actionPerformed(ActionEvent e) { //whenever we choose an option on the combobox 
						f.validate();
						if("Random" == cbMin.getItemAt(cbMin.getSelectedIndex())) {
							players[1] = new Player(board, "Minotaur", 1, board.getN() / 2 ,board.getN() / 2); // minotaur
						}
						else if("Simple" == cbMin.getItemAt(cbMin.getSelectedIndex())) {
							players[1] = new SimplePlayer(board, "Minotaur", 1, board.getN() / 2 ,board.getN() / 2); // minotaur
						}
						
					}  
				});
				
				//Slider for speed
				JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 50);
				slider.setBounds(10, 150, 170, 50);
				slider.setBackground(color);
				f.add(slider);
				
				//Buttons
				JButton bPlay=new JButton("Play"); 
			    bPlay.setBounds(350,800,130,40);
			    f.add(bPlay);
			    bPlay.setEnabled(false);
			    
			    JButton bRestart=new JButton("Restart"); 
			    bRestart.setBounds(500,800,150,40);
			    f.add(bRestart);
			    bRestart.setEnabled(false);
				
				JButton bGen=new JButton("Generate Board"); 
			    bGen.setBounds(180,800,150,40);
			    f.add(bGen); 
			    
			    //Listeners
			    
			    //Listener for Generate
			    bGen.addActionListener(new ActionListener(){  
			        public void actionPerformed(ActionEvent e){ 
			        	  board.createBoard(); // creates Board
			        	  players[1].setX(N/2);
			        	  players[1].setY(N/2);
			        	  
			        	  if(game.whatPlayer == 0) {
								players[0] = new Player(board, "Theseus", 0, 0 ,0); // theseus
							}
							else if(game.whatPlayer == 1) {
								players[0] = new HeuristicPlayer(board, "Theseus", 0, 0 ,0,N*N/2, weight); // theseus
							}
							else if(game.whatPlayer == 2) {
								players[0] = new MinMaxPlayer(board, "Theseus", 0, 0 ,0,N*N/2, weight, 6, false, true); // theseus
							}
			        	  
			        	  game.setRound(0);
	                      DisplayGraphics display = new DisplayGraphics(board,players);
	                      display.setBounds(180, 60, 601, 601);
	                      f.add(display);
	                      bPlay.setEnabled(true);
	                      bRestart.setEnabled(true);
	                      f.repaint();
	                      printTable(board,0,112);
	                      f.revalidate();
						
			        }
			    });
			    
				//Listener for quit
			    JButton bQuit = new JButton("Quit");
			    bQuit.setBounds(680, 800, 70, 40);
			    f.add(bQuit);
			    bQuit.addActionListener(new ActionListener(){  
			        public void actionPerformed(ActionEvent e){ 
			        	f.dispose();
			        	System.exit(0);
			        }
			    });
			    
			    
			    //Listener for restart
				bRestart.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						game.setRound(0);
						board.setSupplies(board.ogSupplies);
						players[1].setX(N / 2);
						players[1].setY(N / 2);
						if(game.whatPlayer == 0) {
							players[0] = new Player(board, "Theseus", 0, 0 ,0); // theseus
						}
						else if(game.whatPlayer == 1) {
							players[0] = new HeuristicPlayer(board, "Theseus", 0, 0 ,0,N*N/2, weight); // theseus
						}
						else if(game.whatPlayer == 2) {
							players[0] = new MinMaxPlayer(board, "Theseus", 0, 0 ,0,N*N/2, weight, 6, false, true); // theseus
						}
						bGen.setEnabled(true);
						bPlay.setEnabled(true);
						cbTheseus.setEnabled(true);
						cbMin.setEnabled(true);
						f.repaint();
						f.revalidate();
						game.setRestart(true);
						
					}
				});
			    
				//Listener for slider
				slider.addChangeListener(new ChangeListener() {
					public void stateChanged(ChangeEvent e) {
						game.speed = 100 - slider.getValue();
					}
				});
				
				
				//Listener for play
			    bPlay.addActionListener(new ActionListener(){  
			        public void actionPerformed(ActionEvent e){ 
			        	new Thread() {
			                public void run() {
			                	cbTheseus.setEnabled(false);
			                	cbMin.setEnabled(false);
			                	bGen.setEnabled(false);
			                	bPlay.setEnabled(false);
			                	game.setRestart(false);
			                	boolean turn = setTurns();
								while(game.getRound() < totalRounds && !game.getRestart()) {//an extra condition from the restart
									
									l6.setText("Round: " + (game.getRound() + 1));
									System.out.println("");
									System.out.println("This is round: " + (game.getRound() + 1)); // prints the current round
									
									int array1[] = {0, 0, 0, -1 };
									int array2[] = {N*N/2, N/2, N/2, -1 };
									
									if(!turn) {//Theseus plays first
										//Theseus
										System.out.println("This is Theseus turn."); // prints theseus turn and if he got stuck or got a supply
										int temp = players[0].getX() * board.getN() + players[0].getY();//TheseusId
										array1 = players[0].getNextMove(temp,players[1].getX() * board.getN() + players[1].getY());
										
										if(temp == array1[0]) {//Printing the proper Messages
											System.out.println("He is stuck!");
										}else System.out.println("He moved to tile " + array1[0]);
										
										if(array1[3] != -1 && board.getSupplies()[array1[3]].getSupplyTileId() != 0) { // if theseus got a supply that isn't at (0,0), move the supply to (0,0) and show it
											System.out.println("He got S" + (array1[3] + 1) + " supply!");
											players[0].setScore(players[0].getScore() + 1);
											board.getSupplies()[array1[3]].setSupplyTileId(0);
											board.getSupplies()[array1[3]].setX(0);
											board.getSupplies()[array1[3]].setY(0);
											l3.setText("Total Score: " + players[0].getScore());
										}
										
										boolean check = true; // checks if all the supplies are at the tile 0
										for(int i = 0; i < board.getS(); i++) {
											if(board.getSupplies()[i].getSupplyTileId() != 0) {
												check = false;
												break;
											}
										}
										
										
										
										// setting the new coordinates of Theseus
										players[0].setX(array1[1]);
										players[0].setY(array1[2]);
										l2.setText("Move Score: " + (game.getRound() + 1));
										//graph
										f.repaint();
										
										// winning condition for theseus
										if(check) {
											JOptionPane.showMessageDialog(f,"THESEUS GOT ALL THE SUPPLIES!!! Theseus Wins!");
											System.out.println("THESEUS GOT ALL THE SUPPLIES!!! Theseus Wins!");
											break;
										}
										// winning condition for minotaur
										if((players[0].getX() * board.getN() + players[0].getY()) == (players[1].getX() * board.getN() + players[1].getY())) {
											JOptionPane.showMessageDialog(f,"Theseus died...Minotaur Wins");
											System.out.println("Theseus died...Minotaur Wins");
											break;
										}
										
								        try
								        {
								            Thread.sleep(game.speed);
								        }
								        catch(InterruptedException ex)
								        {
								            Thread.currentThread().interrupt();
								        }
										
										//Minotaur
								        System.out.println("This is Minotaur turn."); // prints minotaur turn and if he got stuck
										int temp2 = players[1].getX() * board.getN() + players[1].getY();
										array2 = players[1].getNextMove(temp2, players[0].getX() * board.getN() + players[0].getY());
										
										if(temp2 == array2[0]) {
											System.out.println("He is stuck!");
										}else System.out.println("He moved to tile " + array2[0]);
										
										players[1].setX(array2[1]);
										players[1].setY(array2[2]);
										l5.setText("Move Score: " + (game.getRound() + 1));
										
										//graph
										f.repaint();
								        try
								        {
								            Thread.sleep(game.speed);
								        }
								        catch(InterruptedException ex)
								        {
								            Thread.currentThread().interrupt();
								        }
										
									}
									else {
										//Minotaur
										System.out.println("This is Minotaur turn."); // prints minotaur turn and if he got stuck
										int temp2 = players[1].getX() * board.getN() + players[1].getY();
										array2 = players[1].getNextMove(temp2, players[0].getX() * board.getN() + players[0].getY());
										
										if(temp2 == array2[0]) {
											System.out.println("He is stuck!");
										}else System.out.println("He moved to tile " + array2[0]);
										
										players[1].setX(array2[1]);
										players[1].setY(array2[2]);
										l5.setText("Move Score: " + (game.getRound() + 1));
										//graph
										f.repaint();
								        try
								        {
								            Thread.sleep(game.speed);
								        }
								        catch(InterruptedException ex)
								        {
								            Thread.currentThread().interrupt();
								        }
										
								        boolean check = true; // checks if all the supplies are at the tile 0
										for(int i = 0; i < board.getS(); i++) {
											if(board.getSupplies()[i].getSupplyTileId() != 0) {
												check = false;
												break;
											}
										}
										
										// winning condition for theseus
										if(check) {
											JOptionPane.showMessageDialog(f,"THESEUS GOT ALL THE SUPPLIES!!! Theseus Wins!");
											System.out.println("THESEUS GOT ALL THE SUPPLIES!!! Theseus Wins!");
											break;
										}
										// winning condition for minotaur
										if((players[0].getX() * board.getN() + players[0].getY()) == (players[1].getX() * board.getN() + players[1].getY())) {
											JOptionPane.showMessageDialog(f,"Theseus died...Minotaur Wins");
											System.out.println("Theseus died...Minotaur Wins");
											break;
										}
								        
								        //Theseus
										System.out.println("This is Theseus turn."); // prints theseus turn and if he got stuck or got a supply
										int temp = players[0].getX() * board.getN() + players[0].getY();//TheseusId
										array1 = players[0].getNextMove(temp,players[1].getX() * board.getN() + players[1].getY());
										
										if(temp == array1[0]) {//Printing the proper Messages
											System.out.println("He is stuck!");
										}else System.out.println("He moved to tile " + array1[0]);
										
										if(array1[3] != -1 && board.getSupplies()[array1[3]].getSupplyTileId() != 0) { // if theseus got a supply that isn't at (0,0), move the supply to (0,0) and show it
											System.out.println("He got S" + (array1[3] + 1) + " supply!");
											players[0].setScore(players[0].getScore() + 1);
											board.getSupplies()[array1[3]].setSupplyTileId(0);
											board.getSupplies()[array1[3]].setX(0);
											board.getSupplies()[array1[3]].setY(0);
											l3.setText("Total Score: " + players[0].getScore());
										}
										
										
										// setting the new coordinates of Theseus
										players[0].setX(array1[1]);
										players[0].setY(array1[2]);
										l2.setText("Move Score: " + (game.getRound() + 1));
										
										//graph
										f.repaint();
								        try
								        {
								            Thread.sleep(game.speed);
								        }
								        catch(InterruptedException ex)
								        {
								            Thread.currentThread().interrupt();
								        }
										
								        
								        
									}
									
									// prints updated board
									for(int i = board.getN() * 2; i > -1; i--) {
										for(int j = 0; j < board.getN(); j++) {
											System.out.print(board.getStringRepresentation(array1[0],array2[0])[i][j]);
										}
										System.out.println("");
									}
		
									// increasing round by 1
									game.setRound(game.getRound() + 1);
									
									boolean check = true; // checks if all the supplies are at the tile 0
									for(int i = 0; i < board.getS(); i++) {
										if(board.getSupplies()[i].getSupplyTileId() != 0) {
											check = false;
											break;
										}
									}
									
									// winning condition for theseus
									if(check) {
										JOptionPane.showMessageDialog(f,"THESEUS GOT ALL THE SUPPLIES!!! Theseus Wins!");
										System.out.println("THESEUS GOT ALL THE SUPPLIES!!! Theseus Wins!");
										break;
									}
									// winning condition for minotaur
									if((players[0].getX() * board.getN() + players[0].getY()) == (players[1].getX() * board.getN() + players[1].getY())) {
										JOptionPane.showMessageDialog(f,"Theseus died...Minotaur Wins");
										System.out.println("Theseus died...Minotaur Wins");
										break;
									}
									
								}
								// tie condition if they run out of turns
								if(game.getRound() == totalRounds) {
									System.out.println("No one won...");
									JOptionPane.showMessageDialog(f,"No one won...");
								}
								players[0].statistics();
								bGen.setEnabled(true);
								//bPlay.setEnabled(true);
								cbTheseus.setEnabled(true);
								cbMin.setEnabled(true);
			                }
			            }.start();
			        }  
			        
			    });
			    
			    
			    
			    
			    f.setSize(1000,950); // size of frame
			    f.setVisible(true); // visible frame
			    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // closes program with X

			}
			
			
				
			public static void main(String[] args) {
				mainProgram();
				//statisticsProgram();
				//weightFinder();
				Toolkit.getDefaultToolkit().beep(); // beep
			}

}