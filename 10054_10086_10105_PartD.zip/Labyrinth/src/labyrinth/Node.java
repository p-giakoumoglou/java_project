package labyrinth;
import java.util.ArrayList;

public class Node { // class Node
	Node parent;
	ArrayList<Node> children;
	int nodeDepth;
	int[] nodeMove; // here we save the tile and the dice
	Board nodeBoard;
	double nodeEvaluation; // we have made evaluate double
	
	public Node() { // constructors
		parent = new Node();
		children = new ArrayList<Node>();
		nodeDepth = -1;
		nodeMove = new int[2];
		nodeBoard = new Board();
		nodeEvaluation = Double.NEGATIVE_INFINITY;
	}
	
	public Node(Node parent, int[] nodeMove) { // this is for the child of a node
		this.parent = parent;
		children = new ArrayList<Node>();
		this.nodeDepth = parent.nodeDepth + 1;
		this.nodeMove = nodeMove;
		this.nodeBoard = parent.nodeBoard;
		nodeEvaluation = 0; 
	}
	
	public Node(Board nodeBoard) { // for root
		parent = null;
		children = new ArrayList<Node>();
		nodeDepth = 0;
		nodeMove = new int[2];
		this.nodeBoard = nodeBoard;
		nodeEvaluation = 0;
	}
	
	 public Node getParent() {
		 return parent;
	 }
	 
	 public void setParent(Node parent) {
		 this.parent = parent;
	 }
	 
	 public ArrayList<Node> getChildren() {
		 return children;
	 }
	 
	 public void setChilder(ArrayList<Node> children) {
		 this.children = children;
	 }
	 
	 public int getNodeDepth() {
		 return nodeDepth;
	 }
	 
	 public void setNodeDepth(int nodeDepth) {
		 this.nodeDepth = nodeDepth;
	 }
	 
	 public int[] getNodeMove() {
		 return nodeMove;
	 }
	 
	 public void setNodeMove(int[] nodeMove) {
		 System.arraycopy(nodeMove, 0, this.nodeMove, 0, 2);
	 }
	 
	 public Board getNodeBoard() {
		 return nodeBoard;
	 }
	 
	 public void setNodeBoard(Board nodeBoard) {
		 this.nodeBoard = nodeBoard;
	 }
	 
	 public double getNodeEvaluation() {
		 return nodeEvaluation;
	 }
	 
	 public void setNodeEvaluation(double nodeEvaluation) {
		 this.nodeEvaluation = nodeEvaluation;
	 }
}

