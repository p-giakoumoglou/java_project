// Aris-Eftychios Kyprianidis 10086 6988252395 akyprian@ece.auth.gr
// Christos Kyratsous 10105 6933359945 chrkyrlaz@ece.auth.gr
// Paschalis Giakoumoglou 10054 6988031719 giakoupg@ece.auth.gr

package labyrinth;

// Class Game 
public class Game {
	int round;
	
// 1st constructor
	public Game() {
		round = 0;
	}
	
// 2nd constructor
	public Game(int round) {
		this.round = round;
	}
	
// getters and setters for class Game
	public int getRound() {
		return round;
	}
	
	public void setRound(int round) {
		this.round = round;
	}
	
	// mains
	//3 for were about 5 minutes , 4 for were about 1.5 hours
		public static void weightFinder() {
			int N = 15; // the dimension of the board
			int totalRounds = 200;
			double max = 0;//initializing the max
			double[] globalWeight = {0,0,0,0,0};
				for(double c = 1; c < 10; c+=0.5) {//for the weight of supply
					System.out.println("c= "+c);
					for(int b = 30; b < 90; b+=2) {//for the weight of dangerous
						//System.out.println("b= "+b);
						for(double d = 10; d < 100; d+=5) {//for the weight explore
							//System.out.println("d= "+d);
							for(double e = 10; e < 100; e+=5) {//for the weight of recently touched
								double[] weight = {10.0, b, c, d, e}; //the set of weights
								double[] globalStats = {0,0,0,0,0,0};
								int games = 0;
								//for each set of weights we run 100 games
								while(games<100) {
									Game game = new Game(); // initializing the game
									Board board = new Board(N, 4, (N * N * 3 + 1) / 2); // initializing the board
									Player[] players = new Player[2]; // creates players
									players[0] = new HeuristicPlayer(board, "Theseus", 0, 0 ,0, N*N/2, weight); // theseus  with a set of weights
									players[1] = new SimplePlayer(board, "Minotaur", 1, board.getN() / 2 ,board.getN() / 2); // minotaur
									board.createBoard(); // creates Board
									
									//rounds, each set has 200 rounds
									while(game.getRound() < totalRounds) {

										int[] array1 = ((HeuristicPlayer)players[0]).getNextMove(players[0].getX() * board.getN() + players[0].getY(),players[1].getX() * board.getN() + players[1].getY());
										if(array1[3] != -1 && board.getSupplies()[array1[3]].getSupplyTileId() != 0) { // if theseus got a supply that isn't at (0,0), move the supply to (0,0) and show it
											players[0].setScore(players[0].getScore() + 1);
											board.getSupplies()[array1[3]].setSupplyTileId(0);
											board.getSupplies()[array1[3]].setX(0);
											board.getSupplies()[array1[3]].setY(0);
										}
										players[0].setX(array1[1]);
										players[0].setY(array1[2]);
										
										int[] array2 = ((SimplePlayer)players[1]).simpleGetNextMove(players[1].getX() * board.getN() + players[1].getY(), players[0].getX() * board.getN() + players[0].getY());
										players[1].setX(array2[1]);
										players[1].setY(array2[2]);
											
							
										// increasing round by 1
										game.setRound(game.getRound() + 1);
										
										boolean check = true; // checks if all the supplies are at the tile 0
										for(int i = 0; i < board.getS(); i++) {
											if(board.getSupplies()[i].getSupplyTileId() != 0) {
												check = false;
												break;
											}
										}
										
										// winning condition for theseus
										if(check) {
											globalStats[0]++;
											globalStats[1]+=game.getRound() + 1;//not used
											break;
										}
										// winning condition for minotaur
										if((players[0].getX() * board.getN() + players[0].getY()) == (players[1].getX() * board.getN() + players[1].getY())) {
											globalStats[2]++;//can be used if we want the minimum loss rate
											globalStats[3]+=game.getRound() + 1;//not used
											globalStats[4]+=players[0].getScore();//not used
											break;
										}
										
									}
									// tie condition if they run out of turns
									if(game.getRound() == totalRounds) { 
										globalStats[5]++;
										//System.out.println("No one won..."); 
									}
									
									games++;
								}
								globalStats[0]/=games;
								if(max < globalStats[0]) {//if the new win rate is better
									max = globalStats[0];//we keep the new win rate
									globalWeight[0] = weight[0];
									globalWeight[1] = weight[1];//not used
									globalWeight[2] = weight[2];//can be used if we want the minimum loss rate
									globalWeight[3] = weight[3];//not used
									globalWeight[4] = weight[4];//not used
								}
								
								for(int i = 0; i < 6; i++) {
									globalStats[i] = 0;
								}
							}
						}
					}
				}
			System.out.println("a= " + globalWeight[0] +" b= " + globalWeight[1] + " c= " + globalWeight[2] + " d= " + globalWeight[3] + " e= " + globalWeight[4]);
			
		}
		
		public static void statisticsProgram() {
			double[] weight = {10.0, 76.0, 2.5, 65.0, 25.0}; 
			double[] globalStats = {0,0,0,0,0,0,0,0};
			int N = 15; // the dimension of the board
			int totalRounds = 200;//the rounds for each game
			int games = 0;
			//we run 10000 games
			while(games<10000) {
				//System.out.println("Game: " + games);
				Game game = new Game(); // initializing the game
				Board board = new Board(N, 4, (N * N * 3 + 1) / 2); // initializing the board
				Player[] players = new Player[2]; // creates players
				players[0] = new HeuristicPlayer(board, "Theseus", 0, 0 ,0, N*N/2, weight); // theseus
				players[1] = new SimplePlayer(board, "Minotaur", 1, board.getN() / 2 ,board.getN() / 2); // minotaur
				board.createBoard(); // creates Board
				//rounds
				while(game.getRound() < totalRounds) {
				
					int[] array1 = ((HeuristicPlayer)players[0]).getNextMove(players[0].getX() * board.getN() + players[0].getY(),players[1].getX() * board.getN() + players[1].getY());
					if(array1[3] != -1 && board.getSupplies()[array1[3]].getSupplyTileId() != 0) { // if theseus got a supply that isn't at (0,0), move the supply to (0,0) and show it
						//System.out.println("He got S" + (array1[3] + 1) + " supply!");
						players[0].setScore(players[0].getScore() + 1);
						board.getSupplies()[array1[3]].setSupplyTileId(0);
						board.getSupplies()[array1[3]].setX(0);
						board.getSupplies()[array1[3]].setY(0);
					}
					players[0].setX(array1[1]);
					players[0].setY(array1[2]);
					
					// setting the new coordinates of the players
					
					int[] array2 = ((SimplePlayer)players[1]).simpleGetNextMove(players[1].getX() * board.getN() + players[1].getY(), players[0].getX() * board.getN() + players[0].getY());
					players[1].setX(array2[1]);
					players[1].setY(array2[2]);
						
		
					// increasing round by 1
					game.setRound(game.getRound() + 1);
					
					boolean check = true; // checks if all the supplies are at the tile 0
					for(int i = 0; i < board.getS(); i++) {
						if(board.getSupplies()[i].getSupplyTileId() != 0) {
							check = false;
							break;
						}
					}
					
					// winning condition for theseus
					if(check) {
						globalStats[0]++;//this is for the total winds
						globalStats[1]+=game.getRound() + 1;//this is for the rounds theseus won
						break;
					}
					// winning condition for minotaur
					if((players[0].getX() * board.getN() + players[0].getY()) == (players[1].getX() * board.getN() + players[1].getY())) {
						globalStats[2]++;//this for the total loses
						globalStats[3]+=game.getRound() + 1;//this for the rounds theseus won
						globalStats[4]+=players[0].getScore();//this is for the supplies won before losing
						if( ((HeuristicPlayer)players[0]).getCheck() == true )//Reminder: check shows if theseus saw the minotaur with vision
							globalStats[6]++;//if he did and he lost that means he made a wrong move, so a suicide (this is prevented for any set from evaluate)
						else globalStats[7]++;//if not the death was an ambush
						
						break;
					}
					
				}
				if(game.getRound() == totalRounds) { 
					globalStats[5]++;
				}
				
				games++;
			}
			//Printing the statis
			System.out.println("Winning Rate " + globalStats[0]/(games+1));
			System.out.println("Average Winning Round " + globalStats[1]/(games+1));
			System.out.println("Losing Rate " + globalStats[2]/(games+1));
			System.out.println("Average Losing Round: " + globalStats[3]/(games+1));
			System.out.println("Average Supplies Won before losing: " + globalStats[4]/(games+1));
			System.out.println("Draws Rate: " + globalStats[5]/(games+1));
			System.out.println("Suicides: " + globalStats[6]);
			System.out.println("Ambushes: " + globalStats[7]);
			
			
		}
		
		public static void mainProgram() {
			Game game = new Game(); // initializing the game
			int N = 15; // the dimension of the board
			int totalRounds = 200;
			Board board = new Board(N, 4, (N * N * 3 + 1) / 2); // initializing the board
			Player[] players = new Player[2]; // creates players
			double[] weight = {10.0, 40.0, 2.5, 20.0, 20.0};
			players[0] = new HeuristicPlayer(board, "Theseus", 0, 0 ,0,N*N + N, weight); // theseus
			players[1] = new SimplePlayer(board, "Minotaur", 1, board.getN() / 2 ,board.getN() / 2); // minotaur
			board.createBoard(); // creates Board
			// prints the starting board
			for(int i = board.getN() * 2; i > -1; i--) {
				for(int j = 0; j < board.getN(); j++) {
					System.out.print(board.getStringRepresentation(0,players[1].getX() * board.getN() + players[1].getY() )[i][j]);
				}
				System.out.println("");
			}
			//rounds
			while(game.getRound() < totalRounds) {
				System.out.println("");
				System.out.println("This is round: " + (game.getRound() + 1)); // prints the current round
				
				System.out.println("This is Theseus turn."); // prints theseus turn and if he got stuck or got a supply
				int temp = players[0].getX() * board.getN() + players[0].getY();//TheseusId
				int[] array1 = ((HeuristicPlayer)players[0]).getNextMove(temp,players[1].getX() * board.getN() + players[1].getY());
				
				if(temp == array1[0]) {//Printing the proper Messages
					System.out.println("He is stuck!");
				}else System.out.println("He moved to tile " + array1[0]);
				
				if(array1[3] != -1 && board.getSupplies()[array1[3]].getSupplyTileId() != 0) { // if theseus got a supply that isn't at (0,0), move the supply to (0,0) and show it
					System.out.println("He got S" + (array1[3] + 1) + " supply!");
					players[0].setScore(players[0].getScore() + 1);
					board.getSupplies()[array1[3]].setSupplyTileId(0);
					board.getSupplies()[array1[3]].setX(0);
					board.getSupplies()[array1[3]].setY(0);
				}
				
				
				// setting the new coordinates of Theseus
				players[0].setX(array1[1]);
				players[0].setY(array1[2]);
				
				System.out.println("This is Minotaur turn."); // prints minotaur turn and if he got stuck
				temp = players[1].getX() * board.getN() + players[1].getY();
				int[] array2 = ((SimplePlayer)players[1]).simpleGetNextMove(temp, players[0].getX() * board.getN() + players[0].getY());
				
				if(temp == array2[0]) {
					System.out.println("He is stuck!");
				}else System.out.println("He moved to tile " + array2[0]);
				
				players[1].setX(array2[1]);
				players[1].setY(array2[2]);
					
				// prints updated board
				for(int i = board.getN() * 2; i > -1; i--) {
					for(int j = 0; j < board.getN(); j++) {
						System.out.print(board.getStringRepresentation(array1[0],array2[0])[i][j]);
					}
					System.out.println("");
				}

				// increasing round by 1
				game.setRound(game.getRound() + 1);
				
				boolean check = true; // checks if all the supplies are at the tile 0
				for(int i = 0; i < board.getS(); i++) {
					if(board.getSupplies()[i].getSupplyTileId() != 0) {
						check = false;
						break;
					}
				}
				
				// winning condition for theseus
				if(check) {
					System.out.println("THESEUS GOT ALL THE SUPPLIES!!! Theseus Wins!");
					break;
				}
				// winning condition for minotaur
				if((players[0].getX() * board.getN() + players[0].getY()) == (players[1].getX() * board.getN() + players[1].getY())) {
					System.out.println("Theseus died...Minotaur Wins");
					break;
				}
				
			}
			// tie condition if they run out of turns
			if(game.getRound() == totalRounds) System.out.println("No one won...");
			((HeuristicPlayer)players[0]).statistics();
		}
			
		public static void main(String[] args) {
			mainProgram();
			//statisticsProgram();
			//weightFinder();
		}

	}
