package labyrinth;
import java.util.ArrayList;

public class HeuristicPlayer extends Player{
	ArrayList<Double[]> path; // saves information for each round
	Board map; // a board that Theseus fills as he explores the labyrinth
	ArrayList<Tile> danger; // an arraylist with dangerous tiles that is built by dangerZone
	int radius; // the radius of dangerZone around Minotaur
	ArrayList<Supply> suppliesFound; // an arraylist that remembers supplies where they were seen in the labyrinth by Theseus
	int lastEnemyPos;// the last position minotaur was seen by Theseus
	int visibleDangerTiles; // the visible tiles that are considered dangerous for Theseus
	int rounds; // the current round
	int[] moveTracker; // saves the dice of each round
	double[] weight; // the weights for the return of evaluate()
	boolean check; // if he has seen Minotaur in the current round
	
	
	public HeuristicPlayer() { // 1st constructor
		super();
		path = new ArrayList<Double[]>();
		map = new Board();
		map.createEmptyTiles(); // we create an empty board so we can refresh it as we explore the labyrinth
		danger = new ArrayList<Tile>();
		radius = 0;
		suppliesFound = new ArrayList<Supply>();
		lastEnemyPos = -1;
		visibleDangerTiles = 0;
		rounds = 0;
		moveTracker = new int[] {0,0,0,0};
	}
	
	public HeuristicPlayer(Board board, String name, int playerId, int x, int y, int startingEnemyPos, double[] weight) { // 2nd constructor
		super(board,name,playerId,x,y);
		path = new ArrayList<Double[]>();
		map = new Board(board.getN(),board.getS(),board.getW());
		map.createEmptyTiles();
		danger = new ArrayList<Tile>();
		radius = 0;
		suppliesFound = new ArrayList<Supply>();
		lastEnemyPos = -1;
		visibleDangerTiles = 0;
		rounds = 0;
		moveTracker = new int[] {0,0,0,0};
		lastEnemyPos =  startingEnemyPos; //if we want to know the starting enemy Pos, if we dont it is -1 
		this.weight = weight;
	}
	
	//getters and setters
	
	public boolean getCheck() {
		return check;
	}
	
	public void setCheck(boolean check) {
		this.check = check;
	}
	
	public int getRadius() {
		return radius;
	}
	
	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	public int getLastEnemyPos() {
		return lastEnemyPos;
	}
	
	public void setLastEnemyPos(int lastEnemyPos) {
		this.lastEnemyPos = lastEnemyPos;
	}
	
	public int getVisibleDangerTiles() {
		return visibleDangerTiles;
	}
	
	public void setVisibleDangerTiles(int visibleDangerTiles) {
		this.visibleDangerTiles = visibleDangerTiles;
	}
	
	public int getRounds() {
		return rounds;
	}
	
	public void setRounds(int rounds) {
		this.rounds = rounds;
	}
	
	public int[] getMoveTracker() {
		return moveTracker;
	}
	
	public void setMoveTracker(int[] moveTracker) {
		System.arraycopy(moveTracker, 0, this.moveTracker, 0, 4);
	}
	
	public double[] getWeight() {
		return weight;
	}
	
	public void setWeight(double[] weight) {
		System.arraycopy(weight, 0, this.weight, 0, 5);
	}
	
	public ArrayList<Supply> getSuppliesFound(){
		return suppliesFound;
	}
	
	public void setSuppliesFound(ArrayList<Supply> suppliesFound) {
		this.suppliesFound = suppliesFound;
	}
	
	public ArrayList<Tile> getDanger(){
		return danger;
	}
	
	public void setDanger(ArrayList<Tile> danger) {
		this.danger = danger;
	}
	
	public ArrayList<Double[]> getPath(){
		return path;
	}
	
	public void setPath(ArrayList<Double[]> path) {
		this.path = path;
	}
	
	public Board getMap() {
		return map;
	}
	
	public void setMap(Board map) {
		this.map = map;
	}
	
	public void dangerZone(int lastEnemyPos, int newRadius) { // the tiles from vision should be excluded!
		int N = board.getN();
		int y = lastEnemyPos % N;
		int x = (lastEnemyPos - y) / N;
		if(danger.size() == 0) {
			danger.add(new Tile(x ,y ,N )); //if it is the first time for radius = 0, we add the minotaur tile
		}
		for(int i = 0; i < newRadius; i++) {
			if((x + newRadius - i) < N && (y + i) < N) //make sure not to go out of bounds
				danger.add(new Tile(x + newRadius - i, y + i,N)); //adding tiles from North to East
			
			if((x - i) >= 0 && (y + newRadius - i) < N)
				danger.add(new Tile(x - i, y + newRadius - i,N));
			
			if((x - newRadius + i) >= 0 && (y - i) >= 0)
				danger.add(new Tile(x - newRadius + i, y - i,N));
			
			if((x + i) < N && (y - newRadius + i) >= 0)
				danger.add(new Tile(x + i, y - newRadius + i,N));
		}
	}
	
	public int exploration(int dice) { //returns the unexplored tiles of the map in a direction
        int N = board.getN();
        int ID = x * N + y;
        int counter = 0;// the unexplored tiles
        int[] diceCase = { N, 1, -N, -1 }; // this is the diceCase for each direction
        int[] diceCase2 = { N - x - 1, N - y - 1, x, y }; // diceCase necessary for the condition to be correct
        int[] diceCase3 = { y, x};
        int[] diceCase4 = { 0, N - 1, N - 1, 0};
        for(int i = -1; i < 2; i++) {
        	if((diceCase3[dice % 2] == diceCase4[dice % 4] && i == -1) || (diceCase3[dice % 2] == diceCase4[(dice + 2) % 4] && i == 1)){ // if the starting position is in the edge of the labyrinth, skip certain itterations
        		continue;
        	}
        	int iter = 0;
        	int temp = ID + i * diceCase[(dice + 1) % 4]; // the position from which Theseus looks at a certain direction
	        while(iter < diceCase2[dice]) { //run while they remain tiles between Theseus position and the edge of the board 
	            int j = diceCase[dice] ;
	            if (!map.getTiles()[temp + j * (iter + 1)].getSeen())// if Theseus hasnt seen the tile, add it to the unexplored tiles
	                counter++;
	            iter++;
	        }
        }
        return counter;
    }

	public void visibleDanger(int currentPos) { // count the visible danger Tiles
		visibleDangerTiles = 0;
        int N = board.getN();
        int[] diceCase = { N, 1, -N, -1 };
        for (int j = 0; j < danger.size(); j++) //check if the current tile has the same id as any danger tile
            if ((currentPos) == danger.get(j).getTileId()) {
                visibleDangerTiles++;
                break;
            }
        //check in the other directions if a tile has the same id as any danger tile
        for (int k = 0; k < 4; k++) {
            int temp = diceCase[k];
            for (int i = 1; i < 4; i++) {
                if ((currentPos + i * temp) >= 0 && (currentPos + i * temp) < (N * N)
                        && !board.getTiles()[currentPos + (i - 1) * temp].getWall(k)) {
                    for (int j = 0; j < danger.size(); j++) {
                        if ((currentPos + i * temp) == danger.get(j).getTileId()) {
                            visibleDangerTiles++;
                            break;
                        }
                    }
                }
                else continue;
            }
        }
    }
	
	public double calcSupplyDist(int Id) { // calculates the distance from the closest supply he has seen
		double min = 99999;
		int N = board.getN();
		int y = Id % N;
		int x = (Id - y) / N;
		for(int i = 0; i < suppliesFound.size(); i++) {
			if(suppliesFound.get(i).getSupplyTileId() != 0) { // if the supply tile id is 0, it means theseus has gotten it 
				double dist = (x - suppliesFound.get(i).getX()) * (x - suppliesFound.get(i).getX()) + (y - suppliesFound.get(i).getY()) * (y - suppliesFound.get(i).getY());
				if(dist < min) {
					min = dist;
				}
			}
		}
		if(min == 99999) { // if he hasnt seen any 
			return Double.POSITIVE_INFINITY;
		}
		return Math.sqrt(min);
	}
	
	public double calcOpponentDist(int Id, int enemyId) { // calculates the distance of theseus from minotaur if he has seen him this round
		int N = board.getN();
		int y1 = Id % N;
		int x1 = (Id - y1) / N;
		int y2 = enemyId % N;
		int x2 = (enemyId - y2) / N;
		if(enemyId == -1) //if he wasnt seen this round
			return Double.POSITIVE_INFINITY;
		double dist = (x1 - x2) * (x1 - x2)  + (y1 - y2) * (y1 - y2);
		return Math.sqrt(dist);
	}
	
	public int gotSupply(int currentPos, int dice) { // returns the supply theseus got this round
		int N = board.getN();
		int[] diceCase = { N, 1, -N, -1 };
		for(int i = 0; i < suppliesFound.size(); i++) {
    		if(suppliesFound.get(i).getSupplyTileId() == (currentPos + diceCase[dice]) && suppliesFound.get(i).getSupplyTileId() != 0) {
    			return suppliesFound.get(i).getSupplyId();
    		}
    	}
		return -1; //  if he hasnt gotten any
	}
	
	public int recentlyTouched(int currentPos, int dice) { //returns the round Theseus stepped on the Tile that he is planning to move
		int N = board.getN();
		int[] diceCase = { N, 1, -N, -1 };
		if(map.getTiles()[currentPos + diceCase[dice]].getRoundTouched() != -1) { //if Theseus has stepped on the Tile, return the round
			return map.getTiles()[currentPos + diceCase[dice]].getRoundTouched();
		}
		else return (rounds - 200); // else return the (current round - 200)
	}

	public boolean vision(int currentPos, int enemyPos) { // makes theseus gather information 3 tiles in each direction, except there is a wall
		int N = board.getN();
		boolean check = false; // where he sees minotaur this round or not
		int[] diceCase = { N, 1, -N, -1 };
		map.getTiles()[currentPos].copyTile(board.getTiles()[currentPos]); // copies the tile of his current position from board to map 
		for(int dice = 0; dice < 4; dice++) {
			for (int i = 1; i < 4; i++) { // makes sure theseus doesnt see over a wall and doesnt see outside the labyrinth
				if (((currentPos + i * diceCase[dice]) >= 0) && ((currentPos + i * diceCase[dice]) < (N * N)) && (!board.getTiles()[currentPos + (i - 1) * diceCase[dice]].getWall(dice))) {
					map.getTiles()[currentPos + i * diceCase[dice]].copyTile(board.getTiles()[currentPos + i * diceCase[dice]]); // copies the tiles he sees 
					if ((currentPos + i * diceCase[dice]) == enemyPos) { // if he sees minotaur
						lastEnemyPos = enemyPos; // refresh the last enemy position
						check = true; 
						radius = 0; // clear the dangerZone so it can restart
						danger.clear();
					}
					for (int j = 0; j < board.getS(); j++) {
						if (((currentPos + i * diceCase[dice]) == board.getSupplies()[j].getSupplyTileId()) && !board.getSupplies()[j].getSeen()) { // if we saw a new supply for the first time
							suppliesFound.add(board.getSupplies()[j]); // add it in suppliesFound
							board.getSupplies()[j].setSeen(true); //and make sure we dont add it again
						} 
					}
	
				}
				else break;
			}
		}
		return check; // returns if we saw minotaur
	}	
	
	public double evaluate(int currentPos, int dice, int enemyPos) { // the evaluation of the move to a direction
		int N = board.getN();
		double opponentDist = Double.POSITIVE_INFINITY, supplyDist, explore, dangerous = 0, recentlyTouched = 0; // these are the components we will evaluate 
		int[] diceCase = { N, 1, -N, -1 };
		dice = dice / 2; // so we can put it on diceCase
		
		if (map.getTiles()[currentPos].getWall(dice)) // if there is a wall, dont move there
			return Double.NEGATIVE_INFINITY;

		for (int i = 0; i < danger.size(); i++) { // here we calculate the dangerous of the move from whether there are dangerous tiles in the diagonal, so he can ambush us and kill us
			if ((danger.get(i).getTileId() == (currentPos + diceCase[dice] + diceCase[(dice + 1) % 4]))) {
				dangerous += (1.0 / (danger.size() - visibleDangerTiles));
			}
			if((danger.get(i).getTileId() == (currentPos + diceCase[dice] + diceCase[(dice + 3) % 4]))) {
				dangerous += (1.0 / (danger.size() - visibleDangerTiles));
			}
		}
		if(check) // if minotaur was seen this round calculate distance
			opponentDist = calcOpponentDist(currentPos + diceCase[dice], lastEnemyPos);
		supplyDist = calcSupplyDist(currentPos + diceCase[dice]); // supply dist
		explore = exploration(dice); // returns the unexplored tiles from that direction
		recentlyTouched = recentlyTouched(currentPos, dice);// returns what round the tile was touched
		
		if (supplyDist == 0) { // if we are on the supply there is a possibility to get killed, but also a higher initiative to get it, so extra cases were created
			if(opponentDist == 1)
				return Double.NEGATIVE_INFINITY;
			return (- weight[0] / opponentDist) - (weight[1] * dangerous) +  3 * weight[2] + ((1.0 / weight[3]) * (1.0 /(N - 1)) * explore)  + ((1.0 / weight[4]) * (1.0 /(N - 1)) * (rounds - recentlyTouched));
		}
		return (- weight[0] / opponentDist) - (weight[1] * dangerous) + (weight[2] / supplyDist) + ((1.0 / weight[3]) * (1.0 /(N - 1)) * explore)  + ((1.0 / weight[4]) * (1.0 /(N - 1)) * (rounds - recentlyTouched));
	}
	
	public int[] getNextMove(int currentPos, int enemyPos) { // finds the best move
		double max; //the best value of a move
		rounds++; //sets current round
		int dice = 0;
		int N = board.getN();
		int[] diceCase = { N, 1, -N, -1};
		if(lastEnemyPos != -1 && radius < 15) // if the radius is too big or we havent seen minotaur we dont create the dangerZone
			dangerZone(lastEnemyPos,++radius);
		else
		{
			danger.clear();
		}
		visibleDanger(currentPos); 
		check = vision(currentPos, enemyPos); // gets vision
		max = evaluate(currentPos,1,enemyPos); 
		dice = 1;
		for(int i = 1; i < 4; i++) { // gets the best move
			double temp = evaluate(currentPos,(2 * i + 1),enemyPos);
			if(max < temp ) {
				dice = 2 * i + 1;
				max = temp;
			}
		}
		dice /= 2;
		map.getTiles()[currentPos + diceCase[dice]].setRoundTouched(rounds); // set the round at the tile theseus is gonna move to 
		int supplyFound = gotSupply(currentPos, dice); // the supply theseus got, if he got
		moveTracker[dice]++; // the direction we chose
		if(check) // the information we collect for stats
			path.add(new Double[] {(2.0 * dice + 1), (double)supplyFound, calcSupplyDist(currentPos + diceCase[dice]), calcOpponentDist(currentPos + diceCase[dice], lastEnemyPos)});
		else path.add(new Double[] {(2.0 * dice + 1), (double)supplyFound, calcSupplyDist(currentPos + diceCase[dice]), Double.POSITIVE_INFINITY});
		// we return an array similar to move, so we dont have to change the game too much
		return new int[] {currentPos + diceCase[dice],(currentPos + diceCase[dice] - ((currentPos + diceCase[dice]) % N)) / N , (currentPos + diceCase[dice]) % N, supplyFound};
	}
	
	public void statistics() { // prints stats at the end of the game
		int sum = 0; // the numbers of supplies he got
		for(int i = 0; i < path.size() - 1; i++) {
			if(path.get(i)[1] != -1) //if he got a supply
				sum++;
			System.out.println("Round: " + (i + 1) +" Dice: " + path.get(i)[0] +" Supplies Theseus got: " + sum + " Distance from closest supply: " + path.get(i)[2] + " Distance from Minotaur: " + path.get(i)[3]);
		}
		System.out.println("Up: " + moveTracker[0]);
		System.out.println("Right: " + moveTracker[1]);
		System.out.println("Down: " + moveTracker[2]);
		System.out.println("Left: " + moveTracker[3]);
	}
	
}

	
