package labyrinth;
import java.util.Random;

// Class Player
public class Player {
	int playerId;
	String name;
	Board board;
	int score;
	int x;
	int y;
	
// 1st constructor
	public Player() {
		playerId = 0;
		name = "";
		score = 0;
		x = 0;
		y = 0;
	}
	
// 2nd constructor
	public Player(Board board, String name, int playerId, int x, int y) {
		this.board = board;
		this.name = name;
		this.playerId = playerId;
		this.x = x;
		this.y = y;
	}
	
// getters and setters of the class Player
	public int getPlayerId() {
		return playerId;
	}
	
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Board getBoard() {
		return board;
	}
	
	public void setBoard(Board board) {
		this.board = board;
	}
	
	public int getScore() {
		return score;
	}
	
	public void setScore(int score) {
		this.score = score;
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	// gives the new coordinates of the player and the supply they got
		public int[] move(int id) {
			Random rand = new Random();
			int N = board.getN();
			int dice = rand.nextInt(4); // random 1,3,5,7 for each direction
			int check = -1; // -1 if they didn't get any supplies
			int[] diceCase = { N, 1, -N, -1 };
			// checks whether it can move the direction it wants and if the player will get
			// a supply
			if (!board.getTiles()[id].getWall(dice)) {
				for (int i = 0; i < board.getS(); i++) {
					if (board.getSupplies()[i].getSupplyTileId() == (id + diceCase[dice])) {
						check = board.getSupplies()[i].getSupplyId();
					}
				}
				//System.out.println("He moved to tile " + (id + diceCase[dice]) + ".");
				// returns the new Tile id, coordinates and the supply ID (if it is -1, he
				// didn't get the supply)
				return new int[] { id + diceCase[dice], (id + diceCase[dice] - ((id + diceCase[dice]) % N)) / N, (id + diceCase[dice]) % N, check };
			}
			// in case he can't move, returns the old position
			//System.out.println("He is stuck.");
			return new int[] { id, x, y, check };
		}
		
}
