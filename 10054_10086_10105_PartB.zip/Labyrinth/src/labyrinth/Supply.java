package labyrinth;

// Class Supply 
public class Supply {
	int supplyId;
	int x;
	int y;
	int supplyTileId;
	
	boolean seen; //we added a new variable. checks if we have seen the supply

// 1st constructor 
	public Supply(){
		supplyId = 0;
		x = -1; //-1 so it isn't initialized in (0,0)
		y = -1;
		supplyTileId = -1;
		seen = false;
	}

// 2nd constructor
	public Supply(Supply sup){
		supplyId = sup.supplyId;
		x = sup.x;
		y = sup.y;
		supplyTileId = sup.supplyTileId;
		seen = sup.seen;
	}
	
	// 3rd constructor
		public Supply(int supplyId, int x, int y, int supplyTileId){
			this.supplyId = supplyId;
			this.x = x; //-1 so it isn't initialized in (0,0)
			this.y = y;
			this.supplyTileId = supplyTileId;
			seen = false;
		}
	
// getters and setters for class Supply
	public int getSupplyId() {
		return supplyId;
	}
	
	public void setSupplyId(int supplyId) {
		this.supplyId = supplyId;
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public int getSupplyTileId() {
		return supplyTileId;
	}
	
	public void setSupplyTileId(int supplyTileId) {
		this.supplyTileId = supplyTileId;
	}
	
	//extra 
	public boolean getSeen() {
		return seen;
	}
	
	public void setSeen(boolean seen) {
		this.seen = seen;
	}
}