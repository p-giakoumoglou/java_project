package labyrinth;

public class SimplePlayer extends Player{ // minotaur player
	
	SimplePlayer(){// same constructors as player
		super();
	}
	public SimplePlayer(Board board, String name, int playerId, int x, int y) {
		super(board,name,playerId,x,y);
	}
	
	public boolean simpleEvaluate(int currentPos, int enemyPos, int dice) { //if he sees theseus he moves towards him
		int N = board.getN();
		int[] diceCase = { N, 1, -N, -1 };
		for (int i = 1; i < 4; i++) { // he sees 3 tiles as well
			if (((currentPos + i * diceCase[dice]) >= 0) && ((currentPos + i * diceCase[dice]) < (N * N)) && (!board.getTiles()[currentPos + (i - 1) * diceCase[dice]].getWall(dice))) {
				if ((currentPos + i * diceCase[dice]) == enemyPos) {
					return true;
				}

			} else
				break;
		}
		return false;
			
	}
	
	public int[] getNextMove(int currentPos, int enemyPos) { //if he sees theseus in a direction he goes there else he calls the old random move
		int N = board.getN();
		int[] diceCase = {N, 1, -N, -1};
		for(int i = 0; i < 4; i++) {
			if(simpleEvaluate(currentPos, enemyPos, i))
				return new int[] {currentPos + diceCase[i],(currentPos + diceCase[i] - ((currentPos + diceCase[i]) % N)) / N , (currentPos + diceCase[i]) % N, -1 };
		}
		return super.getNextMove(x * N + y, -1);
	}
	

}
