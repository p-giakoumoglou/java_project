package labyrinth;

// Class Tile
public class Tile {
	int tileId;
	int x;
	int y;
	boolean up;
	boolean down;
	boolean left;
	boolean right;
	boolean seen; //extra... if it has been seen by Theseus
	int roundTouched;//extra...  the round it was touched by Theseus
	
// 1st constructor
	public Tile() {
		tileId = 0;
		x = 0;
		y = 0;
		up = false;
		down = false;
		left = false;
		right = false;
		seen = false;
		roundTouched = -1;
	}
	
// 2nd constructor
	public Tile(Tile tile) {
		tileId = tile.tileId;
		x = tile.x;
		y = tile.y;
		up = tile.up;
		down = tile.down;
		left = tile.left;
		right = tile.right;
		seen = false;
		roundTouched = -1;
	}
//new 3rd constructor
	public Tile(int x, int y, int N) {
		this.x = x;
		this.y = y;
		tileId = x * N + y;
		up = false;
		down = false;
		left = false;
		right = false;
		seen = false;
		roundTouched = -1;
	}
	
// getters and setters for class Tile
	public int getTileId() {
		return tileId;
	}
	
	public void setTileId(int tileId) {
		this.tileId = tileId;
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	public boolean getUp() {
		return up;
	}
	
	public void setUp(boolean up) {
		this.up = up;
	}
	
	public boolean getDown() {
		return down;
	}
	
	public void setDown(boolean down) {
		this.down = down;
	}
	
	public boolean getLeft() {
		return left;
	}
	
	public void setLeft(boolean left) {
		this.left = left;
	}
	
	public boolean getRight() {
		return right;
	}
	
	public void setRight(boolean right) {
		this.right = right;
	}
	
	//extra
	public boolean getSeen() {
		return seen;
	}
	
	public void setSeen(boolean seen) {
		this.seen = seen;
	}
	
	public int getRoundTouched() {
		return roundTouched;
	}
	
	public void setRoundTouched(int roundTouched) {
		this.roundTouched = roundTouched;
	}
	
	
	public void copyTile(Tile tile) { //copies a tile 
		this.tileId = tile.getTileId();
		this.x = tile.getX();
		this.y = tile.getY();
		this.up = tile.getUp();
		this.down = tile.getDown();
		this.left = tile.getLeft();
		this.right = tile.getRight();
		seen = true;
	}
	
	public boolean getWall(int dice) { //checks for wall in a direction
        switch(dice) {
            case 0:
                return up;
            case 1:
                return right;
            case 2:
                return down;
            case 3:
                return left;
            default:
                return false; 
        }
    }
	
	//new
	public void setWallTrue(int dice) { // sets a wall true in a direction
		switch (dice) {
		case 0:
			up = true;
			break;
		case 1:
			right = true;
			break;
		case 2:
			down = true;
			break;
		case 3:
			left = true;
		}
	
	}
}


