package labyrinth;
import java.util.Random; 

// Class Board
public class Board {
	int N;
    int S;
    int W;
    Tile[] tiles;
    Supply[] supplies;

// 1st constructor
    public Board() {
    	N = 0;
    	S = 0;
    	W = 0;
    }

// 2nd constructor
    public Board(int N, int S, int W) {
        this.N = N;
        this.S = S;
        this.W = W;
        tiles = new Tile[N*N];
        supplies = new Supply[S];
    }
    
// 3rd constructor
    public Board(Board board) {
    	N = board.N;
    	W = board.W;
    	S = board.S;
    	tiles = new Tile[N*N];
        supplies = new Supply[S];
    	System.arraycopy(board.tiles, 0, tiles, 0, N*N);
    	System.arraycopy(board.supplies, 0, supplies, 0, S);
    }
    
// getters and setters for class Board
    public int getN() {
    	return N;
    }
    
    public void setN(int N) {
    	this.N = N;
    }
    public int getS() {
    	return S;
    }
    
    public void setS(int S) {
    	this.S = S;
    }
    public int getW() {
    	return W;
    }
    
    public void setW(int W) {
    	this.W = W;
    }
    
    public Tile[] getTiles() {
    	return tiles;
    }
    
    public void setTiles(Tile[] tiles) {
    	System.arraycopy(tiles, 0, this.tiles, 0, N*N); 
    }
    
    public Supply[] getSupplies() {
    	return supplies;
    }
    
    public void setSupplies(Supply[] supplies) {
    	System.arraycopy(supplies, 0, this.supplies, 0, S);
    }
    
    public void setSupply(Supply supply,int i) {
    	supplies[i] = supply;
    }
    
    // Initializing all the tiles with random wall placement
    public void createTile() {
    	Random rand = new Random();
    	int[] table = new int[N * N]; // table[x] keeps how many walls tiles[x] has
    	for(int x = 0; x < N; x++) { // initialize the tiles[] with their correspondent TileId and coordinates
    		for(int y = 0; y < N; y++) {
    			tiles[x * N + y] = new Tile(x, y, N); //change
   			 	table[x * N + y] = 0;
    		}
    	}
    	// creates external walls
    	for(int i = 0; i < N; i++) {
    		tiles[i].setDown(true);
    		tiles[(N - 1) * N + i].setUp(true);
    		tiles[N * i].setLeft(true);
    		tiles[(N * i) + N - 1].setRight(true);
    		table[i]++;
    		table[(N - 1) * N + i]++;
    		table[N * i]++;
    		table[(N * i) + N - 1]++;
    	}    	
    	// selecting a random tile and putting a wall in a random side(if its possible) ( (W - 4 * N) / 2 because 4 * N are the outside walls and each wall in W counts as 2 walls as it is shared by 2 tiles)
    	int[] diceCase = { N, 1, -N, -1 };
    	//change: used diceCase
		for (int i = 0; i < (W - 4 * N) / 2; i++) {
			int rand_int1 = rand.nextInt(N * N); // the number for the random tile
			int dice = rand.nextInt(4); // the number for the random direction
			// checks if there is a wall above the tile, if there are less than 2 walls in
			// the tile,if the tile above it has less than 2 walls as well
			// (the top line will be ignored because the first expression wont be true and
			// so the array won't go out of bounds)
			if (!tiles[rand_int1].getWall(dice) && table[rand_int1] < 2 && table[rand_int1 + diceCase[dice]] < 2) { //change
				tiles[rand_int1].setWallTrue(dice);
				tiles[rand_int1 + diceCase[dice]].setWallTrue((dice + 2) % 4);
				table[rand_int1]++;
				table[rand_int1 + diceCase[dice]]++;
			}
		}
    	
    }
    
    // adds supplies to random tiles
  //changed variable names and used better constructor
    public void createSupply() {
    	Random rand = new Random();
    	int[] array = new int[S]; // an array with the tile ID of each supply
    	for(int i = 0; i < S; i++) {
    		boolean check = false;
    		int rand_int1 = rand.nextInt(N); // the x coordinate
    		int rand_int2 = rand.nextInt(N); // the y coordinate
    		int SupplyTileId = rand_int1 * N + rand_int2; // the tile ID
    		while(!check) { // checks if the tile of the supply is preoccupied by another supply or the starting position of a player(and creates new coordinates in that case)
    			check = true;
    			for(int j = 0; j < i; j++) {
        			if(array[j] == SupplyTileId) {
        				check = false;
        			}
        		}
    			if(!check || SupplyTileId == 0 || SupplyTileId == (N*N/2)) {
    				rand_int1 = rand.nextInt(N);
    				rand_int2 = rand.nextInt(N);
    				SupplyTileId = rand_int1 * N + rand_int2;
    				check = false;
    			}
        	}
    		array[i] = SupplyTileId;
    		supplies[i] = new Supply(i, rand_int1, rand_int2, SupplyTileId);
    	}
    }
    
    // creates board 
    public void createBoard() {
    	createTile();
    	createSupply();
    }
    
    // saves the board in a string
    public String[][] getStringRepresentation(int theseusTile, int minotaurTile){
    	String[][] board = new String[N * 2 + 1][N]; // the string we will return
    	for(int i = 0; i < (N * 2); i++) {
    		for(int j = 0; j < N; j++) {
    			if(i % 2 == 0) { // if the number is even, and there is a wall under the tile we check, save the wall in the string, else let it empty
    				if(tiles[i/2 * N + j].getDown()) {
    					board[i][j] = "+ - - - ";
    				}
    				
    				else board[i][j] = "+       ";
    			}
    			if(i % 2 == 1) { // if the number is odd, and there is a wall left of the tile we check, save the wall in the string, else let it empty
    				if(tiles[i/2 * N + j].getLeft()) {
    					board[i][j] = "|       ";
    				}
    				else board[i][j] = "        ";
    				
    				if(j == (N - 1)) { // if we are on the last column, we built the right part of the board
    					board[i][j] += "|";
    					board[i - 1][j] += "+";
    				}
    			}
    		}
    	} // this is for the top row of the board
    	for(int j = 0; j < N - 1; j++) {
    		board[N * 2][j] = "+ - - - ";
    	}
    	board[N * 2][N - 1] = "+ - - - +";
    	
    	//puts minotaur in the new place
    	int j = minotaurTile % N; //coordinates of minotaur
    	int i = 2 * ((minotaurTile - j) / N) + 1;
    	for(int k = 0; k < S; k++) { //  for the case that minotaur steps on a supply(and it wasn't taken by theseus)
    		if(supplies[k].getSupplyTileId() == minotaurTile && supplies[k].getSupplyTileId() != 0) {
    			board[i][j] = board[i][j].replace("       ","  S" + (k+1) + " M ");
    		}
    	}
    	board[i][j] = board[i][j].replace("       ","   M   ");
    	
    	//puts theseus in the new place
    	j = theseusTile % N; //coordinates of theseus
    	i = 2 * ((theseusTile - j) / N) + 1;
    	board[i][j] = board[i][j].replace("       ","   T   ");
    	
    	//puts supplies at the board, ignoring the ones that have been moved at the start of the board
    	for(int k = 0; k < S; k++) {
    		if(supplies[k].getSupplyTileId() == 0) {
    			continue;
    		}
    		j = supplies[k].supplyTileId % N;// supply coordinates
        	i = 2 *((supplies[k].supplyTileId - j) / N) + 1;
        	board[i][j] = board[i][j].replace("       ","   S" + (k + 1) + "  ");
    	}
    	//delete the first wall of the first row(due to the examples)
    	board[0][0] = board[0][0].replace(" - - - ","       ");
    	
    	return board;
    }
    
    public void createEmptyTiles() { // create a completely empty board NxN 
    	for(int x = 0; x < N; x++) { 
    		for(int y = 0; y < N; y++) {
    			 tiles[x * N + y] = new Tile();
    			 tiles[x * N + y].setX(x);
    			 tiles[x * N + y].setY(y);
    			 tiles[x * N + y].setTileId(x * N + y);
    		}
    	}
    }
}
    
    
    

